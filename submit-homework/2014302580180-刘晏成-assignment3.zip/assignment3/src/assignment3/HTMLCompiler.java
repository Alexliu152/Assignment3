/**
 * 
 */
package assignment3;

/**
 * @author 2014302580180 ���̳�  WHU-ISS
 *
 */
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class HTMLCompiler {
	public static void main(String[] args)throws IOException{
		Document doc = Jsoup.connect("http://www.wpi.edu/academics/cs/research-interests.html").get();
		Elements a=doc.getElementsByClass("half");
		Elements hrefs = a.select("a[href]"); 
        for(Element i:hrefs)  
           {  
            String tag=i.tagName();  
            if(tag.equals("li"))  
                {  
                  System.out.println(i.text());  
           
                }  
      
       
           }  
           
       }
	}
